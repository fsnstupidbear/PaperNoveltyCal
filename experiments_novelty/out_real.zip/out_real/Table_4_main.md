| Method | Accuracy | AUC | nDCG@10 | Precision@10 |
|---|---:|---:|---:|---:|
| Ours (PAIR, meta) | 0.824773413897281 |  |  |  |
| Ours (RET, base) |  |  | 0.142268526136687 | 0.159214501510574 |
| Ours (RET, fusion-UB) |  |  | 0.142268526136687 | 0.159214501510574 |